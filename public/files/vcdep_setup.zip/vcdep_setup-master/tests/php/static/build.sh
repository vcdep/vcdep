#! /bin/bash

phpcs /cdep/repos/$1/index/*.php
