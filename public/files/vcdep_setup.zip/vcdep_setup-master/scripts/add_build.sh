#! /bin/bash

curl -X POST http://34.230.59.198/vcdep/build
