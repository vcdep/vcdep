#! /bin/bash

phpunit /cdep/repos/$1/tests/localTester.php
