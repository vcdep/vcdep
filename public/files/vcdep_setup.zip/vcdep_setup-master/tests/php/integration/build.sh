#! /bin/bash

phpunit /cdep/repos/$1/tests/Tester.php
