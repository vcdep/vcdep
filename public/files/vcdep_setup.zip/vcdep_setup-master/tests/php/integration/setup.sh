wget https://phar.phpunit.de/phpunit-7.1.phar
chmod +x phpunit-7.1.phar
mv phpunit-7.1.phar /usr/local/bin/phpunit
phpunit --version
