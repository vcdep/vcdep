#! /bin/bash

cd docker-compose
sudo docker-compose build
sudo docker-compose push
